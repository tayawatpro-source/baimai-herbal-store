// 1) สร้าง Google Sheet ใหม่ แล้วเปิด Extensions > Apps Script
// 2) วางโค้ดนี้แทนโค้ดเดิม จากนั้น Deploy > New deployment > Web app
// 3) Execute as: Me และ Who has access: Anyone (พิจารณาความเสี่ยงก่อนใช้งานจริง)
// 4) คัดลอก Web app URL ไปใส่ใน GOOGLE_SHEETS_ENDPOINT ใน app.js

const SHEET_NAME = "Orders";
const HEADERS = [
  "orderId", "createdAt", "sku", "product", "quantity", "unitPrice",
  "total", "customer", "phone", "address", "note", "status"
];

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
  if (sheet.getLastRow() === 0) sheet.appendRow(HEADERS);
  return sheet;
}

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const sheet = getSheet_();
    sheet.appendRow(HEADERS.map(key => data[key] === undefined ? "" : data[key]));
    return ContentService.createTextOutput(JSON.stringify({ok:true, orderId:data.orderId}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false, error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  const sheet = getSheet_();
  const values = sheet.getDataRange().getValues();
  if (values.length < 2) {
    return ContentService.createTextOutput("[]").setMimeType(ContentService.MimeType.JSON);
  }
  const headers = values.shift();
  const orders = values.map(row => Object.fromEntries(headers.map((h, i) => [h, row[i]])));
  return ContentService.createTextOutput(JSON.stringify(orders))
    .setMimeType(ContentService.MimeType.JSON);
}
