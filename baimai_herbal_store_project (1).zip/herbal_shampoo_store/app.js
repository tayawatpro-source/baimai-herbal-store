// ใส่ URL ของ Google Apps Script Web App หลัง Deploy ในบรรทัดด้านล่าง
const GOOGLE_SHEETS_ENDPOINT = "ใส่_URL_WEB_APP_ที่นี่";

const products = {
  "BM-KF250": { name: "แชมพูมะกรูด", price: 159 },
  "BM-AP250": { name: "แชมพูอัญชัน", price: 169 }
};
const productSelect = document.getElementById("product");
const quantityInput = document.getElementById("quantity");
const totalEl = document.getElementById("total");
const statusEl = document.getElementById("formStatus");

function updateTotal() {
  const item = products[productSelect.value];
  const qty = Math.max(1, Number(quantityInput.value) || 1);
  totalEl.textContent = "฿" + (item.price * qty).toLocaleString("th-TH");
}
productSelect.addEventListener("change", updateTotal);
quantityInput.addEventListener("input", updateTotal);
document.querySelectorAll(".add-btn[data-product]").forEach(btn => {
  btn.addEventListener("click", () => {
    productSelect.value = btn.dataset.product;
    updateTotal();
    document.getElementById("order").scrollIntoView({behavior:"smooth"});
  });
});

document.getElementById("orderForm").addEventListener("submit", async event => {
  event.preventDefault();
  const product = products[productSelect.value];
  const qty = Number(quantityInput.value);
  const order = {
    orderId: "BM" + Date.now().toString().slice(-8),
    createdAt: new Date().toLocaleString("th-TH"),
    sku: productSelect.value,
    product: product.name,
    quantity: qty,
    unitPrice: product.price,
    total: product.price * qty,
    customer: document.getElementById("customer").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    address: document.getElementById("address").value.trim(),
    note: document.getElementById("note").value.trim(),
    status: "รอจัดส่ง"
  };
  const button = event.target.querySelector('button[type="submit"]');
  button.disabled = true;
  statusEl.textContent = "กำลังบันทึกคำสั่งซื้อ...";
  try {
    if (GOOGLE_SHEETS_ENDPOINT.startsWith("https://")) {
      await fetch(GOOGLE_SHEETS_ENDPOINT, {
        method: "POST",
        mode: "no-cors",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(order)
      });
      statusEl.textContent = "ส่งคำสั่งซื้อแล้ว หากเชื่อม Google Sheets ถูกต้อง รายการจะถูกบันทึกในชีต";
    } else {
      const orders = JSON.parse(localStorage.getItem("baimaiOrders") || "[]");
      orders.unshift(order);
      localStorage.setItem("baimaiOrders", JSON.stringify(orders));
      statusEl.textContent = "บันทึกตัวอย่างคำสั่งซื้อในเบราว์เซอร์แล้ว (ยังไม่ได้เชื่อม Google Sheets)";
    }
    event.target.reset();
    updateTotal();
  } catch (error) {
    statusEl.textContent = "เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง";
  } finally {
    button.disabled = false;
  }
});

if (new URLSearchParams(location.search).get("admin") === "1") {
  document.getElementById("adminPanel").hidden = false;
  loadOrders();
}
document.getElementById("refreshOrders").addEventListener("click", loadOrders);

async function loadOrders() {
  const list = document.getElementById("ordersList");
  list.innerHTML = "<p>กำลังโหลดรายการ...</p>";
  let orders = [];
  try {
    if (GOOGLE_SHEETS_ENDPOINT.startsWith("https://")) {
      const response = await fetch(GOOGLE_SHEETS_ENDPOINT);
      orders = await response.json();
    } else {
      orders = JSON.parse(localStorage.getItem("baimaiOrders") || "[]");
    }
  } catch (e) {
    list.innerHTML = "<p>โหลดข้อมูลไม่ได้ ตรวจสอบ URL และสิทธิ์การเผยแพร่ Google Apps Script</p>";
    return;
  }
  if (!orders.length) {
    list.innerHTML = "<p>ยังไม่มีคำสั่งซื้อ</p>";
    return;
  }
  list.innerHTML = "";
  orders.slice().reverse().forEach(order => {
    const card = document.createElement("article");
    card.className = "order-admin-card";
    const info = document.createElement("div");
    const safe = value => String(value ?? "");
    info.innerHTML = `<b>${safe(order.orderId)} · ${safe(order.customer)}</b>
      <p>${safe(order.product)} (${safe(order.sku)}) × ${safe(order.quantity)} · รวม ฿${safe(order.total)}</p>
      <p>โทร. ${safe(order.phone)}<br>${safe(order.address)}<br>วันที่: ${safe(order.createdAt)}</p>`;
    const print = document.createElement("button");
    print.className = "add-btn";
    print.textContent = "พิมพ์ใบปะหน้า";
    print.addEventListener("click", () => printShippingLabel(order));
    card.append(info, print);
    list.append(card);
  });
}

function printShippingLabel(order) {
  const label = document.createElement("div");
  label.id = "printLabel";
  label.style.cssText = "font-family:Arial,sans-serif;max-width:700px;margin:20px auto;padding:25px;border:2px solid #111;color:#111";
  const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  label.innerHTML = `<h2 style="text-align:center">ใบปะหน้าพัสดุ · BAIMAI</h2><hr>
    <h3>ผู้รับ (TO)</h3><p style="font-size:20px"><b>${escapeHtml(order.customer)}</b></p>
    <p style="font-size:17px;line-height:1.8">${escapeHtml(order.address)}</p>
    <p style="font-size:18px">โทร. ${escapeHtml(order.phone)}</p><hr>
    <p>เลขคำสั่งซื้อ: ${escapeHtml(order.orderId)}</p>
    <p>สินค้า: ${escapeHtml(order.product)} (${escapeHtml(order.sku)})</p>
    <p>จำนวน: ${escapeHtml(order.quantity)} ชิ้น</p><p>หมายเหตุ: ${escapeHtml(order.note)}</p>`;
  document.body.append(label);
  window.print();
  label.remove();
}
